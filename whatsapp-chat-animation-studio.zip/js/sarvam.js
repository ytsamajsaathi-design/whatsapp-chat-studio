/**
 * Sarvam AI Text-to-Speech (TTS) Client
 * Integration for Sarvam AI Bulbul models (bulbul:v3, bulbul:v2)
 * Documentation: https://docs.sarvam.ai
 *
 * Capabilities:
 * - 11 Indian Languages (hi-IN, en-IN, bn-IN, ta-IN, te-IN, kn-IN, ml-IN, mr-IN, gu-IN, pa-IN, od-IN)
 * - 38 natural Indian speaker voices (Male & Female)
 * - Models: bulbul:v3 (flagship high-expressive) & bulbul:v2
 * - Dynamic controls: pace (0.5x - 2.0x), temperature (0.01 - 1.0), sample rate (up to 48kHz)
 * - Base64 audio decoding into native Web Audio buffer & Blob
 * - Intelligent language detection by script
 * - Browser Web Speech fallback when offline or no API key is entered
 */
class SarvamClient {
  constructor() {
    this.apiKey = localStorage.getItem('sarvam_api_key') || '';
    this.defaultModel = 'bulbul:v3';
    this.defaultSpeaker = 'shubh';
    this.defaultLanguage = 'hi-IN';

    // Supported Models
    this.models = [
      {
        id: 'bulbul:v3',
        name: 'Bulbul v3 (Latest Flagship)',
        description: 'Ultra-realistic Indian TTS with 38 voices, expressive prosody, pace & temperature controls',
        languagesCount: 11,
        maxChars: 2500,
        supportsPace: true,
        supportsTemperature: true
      },
      {
        id: 'bulbul:v2',
        name: 'Bulbul v2 (Legacy)',
        description: 'Standard Indian TTS model with pace control (0.3x - 3.0x)',
        languagesCount: 11,
        maxChars: 1500,
        supportsPace: true,
        supportsTemperature: false
      }
    ];

    // Supported 11 Languages with BCP-47 codes
    this.languages = [
      { code: 'hi-IN', name: 'Hindi', native: 'हिन्दी', script: 'Devanagari' },
      { code: 'en-IN', name: 'Indian English', native: 'English (IN)', script: 'Latin' },
      { code: 'bn-IN', name: 'Bengali', native: 'বাংলা', script: 'Bengali' },
      { code: 'ta-IN', name: 'Tamil', native: 'தமிழ்', script: 'Tamil' },
      { code: 'te-IN', name: 'Telugu', native: 'తెలుగు', script: 'Telugu' },
      { code: 'kn-IN', name: 'Kannada', native: 'ಕನ್ನಡ', script: 'Kannada' },
      { code: 'ml-IN', name: 'Malayalam', native: 'മലയാളം', script: 'Malayalam' },
      { code: 'mr-IN', name: 'Marathi', native: 'मराठी', script: 'Devanagari' },
      { code: 'gu-IN', name: 'Gujarati', native: 'ગુજરાતી', script: 'Gujarati' },
      { code: 'pa-IN', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', script: 'Gurmukhi' },
      { code: 'od-IN', name: 'Odia', native: 'ଓଡ଼ିଆ', script: 'Odia' }
    ];

    // 38 Verified Speaker Voices for Bulbul v3
    this.speakers = [
      // 👨 Male Voices (23)
      { id: 'shubh', name: 'Shubh', gender: 'male', tag: 'Natural & Warm (Default)', desc: 'Conversational, everyday Hindi & Indian English' },
      { id: 'aditya', name: 'Aditya', gender: 'male', tag: 'Energetic & Youthful', desc: 'Modern tech, podcast, upbeat casual chat' },
      { id: 'rahul', name: 'Rahul', gender: 'male', tag: 'Friendly & Casual', desc: 'Youthful friend, messaging dialogue, WhatsApp audio' },
      { id: 'rohan', name: 'Rohan', gender: 'male', tag: 'Deep & Resonant', desc: 'Narrator, storytelling, expressive audio' },
      { id: 'amit', name: 'Amit', gender: 'male', tag: 'Professional & Clear', desc: 'Business, educational, articulate delivery' },
      { id: 'dev', name: 'Dev', gender: 'male', tag: 'Dynamic & Charismatic', desc: 'Conversational, storytelling, dynamic tone' },
      { id: 'ratan', name: 'Ratan', gender: 'male', tag: 'Mature & Dignified', desc: 'Authoritative, calm, wise voiceover' },
      { id: 'varun', name: 'Varun', gender: 'male', tag: 'Engaging Commercial', desc: 'Commercial style, active listener, crisp' },
      { id: 'manan', name: 'Manan', gender: 'male', tag: 'Youthful & Bright', desc: 'Light, friendly, student persona' },
      { id: 'sumit', name: 'Sumit', gender: 'male', tag: 'Conversational & Calm', desc: 'Natural pacing, mild cadence' },
      { id: 'kabir', name: 'Kabir', gender: 'male', tag: 'Poetic & Expressive', desc: 'Rich dramatic storytelling voice' },
      { id: 'aayan', name: 'Aayan', gender: 'male', tag: 'Modern Urban', desc: 'Contemporary Hinglish & English dialogue' },
      { id: 'ashutosh', name: 'Ashutosh', gender: 'male', tag: 'Formal & News', desc: 'Clear announcements, formal reports' },
      { id: 'advait', name: 'Advait', gender: 'male', tag: 'Warm Storyteller', desc: 'Audiobooks, documentary, gentle tone' },
      { id: 'anand', name: 'Anand', gender: 'male', tag: 'Cheerful & Upbeat', desc: 'Friendly assistant, cheerful banter' },
      { id: 'tarun', name: 'Tarun', gender: 'male', tag: 'Tech Savvy', desc: 'Fast, articulate, startup founder tone' },
      { id: 'sunny', name: 'Sunny', gender: 'male', tag: 'Casual Street Style', desc: 'Youth banter, gaming, upbeat' },
      { id: 'mani', name: 'Mani', gender: 'male', tag: 'South Indian Nuance', desc: 'Natural Tamil/Telugu/English bilingual cadence' },
      { id: 'gokul', name: 'Gokul', gender: 'male', tag: 'Gentle & Sincere', desc: 'Sincere, polite, empathetic' },
      { id: 'vijay', name: 'Vijay', gender: 'male', tag: 'Confident & Heroic', desc: 'Strong, cinematic, punchy lines' },
      { id: 'mohit', name: 'Mohit', gender: 'male', tag: 'Everyday Buddy', desc: 'Casual texting partner, casual talk' },
      { id: 'rehan', name: 'Rehan', gender: 'male', tag: 'Smooth & Melodic', desc: 'Smooth podcast voice, gentle inflections' },
      { id: 'soham', name: 'Soham', gender: 'male', tag: 'Clear & Analytical', desc: 'Explainer videos, tutorials, distinct' },

      // 👩 Female Voices (15)
      { id: 'ritu', name: 'Ritu', gender: 'female', tag: 'Crisp & Engaging (Default)', desc: 'Clear, modern, expressive conversational Hindi & English' },
      { id: 'priya', name: 'Priya', gender: 'female', tag: 'Warm & Empathetic', desc: 'Conversational best friend, gentle cadence, WhatsApp voice note' },
      { id: 'neha', name: 'Neha', gender: 'female', tag: 'Youthful & Energetic', desc: 'Upbeat vlogger, modern chat, casual texting' },
      { id: 'pooja', name: 'Pooja', gender: 'female', tag: 'Calm & Soothing', desc: 'Relaxed, smooth narrative tone' },
      { id: 'simran', name: 'Simran', gender: 'female', tag: 'Cheerful & Vibrant', desc: 'Happy, fast banter, expressive emotions' },
      { id: 'kavya', name: 'Kavya', gender: 'female', tag: 'Narrator & Audiobooks', desc: 'Articulate, descriptive, rich storytelling tone' },
      { id: 'ishita', name: 'Ishita', gender: 'female', tag: 'Professional & Polished', desc: 'Corporate, presentations, confident voice' },
      { id: 'shreya', name: 'Shreya', gender: 'female', tag: 'Sweet & Friendly', desc: 'Empathetic, helpful, friendly dialogue' },
      { id: 'roopa', name: 'Roopa', gender: 'female', tag: 'Mature & Grounded', desc: 'Experienced, comforting, trustworthy persona' },
      { id: 'tanya', name: 'Tanya', gender: 'female', tag: 'Modern Urbanite', desc: 'Chic, contemporary Hinglish speaker' },
      { id: 'shruti', name: 'Shruti', gender: 'female', tag: 'Clear & Articulate', desc: 'Podcast host, educational, engaging' },
      { id: 'suhani', name: 'Suhani', gender: 'female', tag: 'Light & Cheerful', desc: 'Bubbly, spontaneous chat, social media' },
      { id: 'kavitha', name: 'Kavitha', gender: 'female', tag: 'South Indian Nuance', desc: 'Natural Tamil/Telugu/Kannada bilingual flow' },
      { id: 'rupali', name: 'Rupali', gender: 'female', tag: 'Expressive & Dramatic', desc: 'Emotional depth, cinema dialogues' },
      { id: 'niharika', name: 'Niharika', gender: 'female', tag: 'Gentle & Poised', desc: 'Soft narrative voice, elegant delivery' }
    ];
  }

  setApiKey(key) {
    this.apiKey = (key || '').trim();
    localStorage.setItem('sarvam_api_key', this.apiKey);
  }

  getApiKey() {
    return this.apiKey;
  }

  hasApiKey() {
    return !!this.apiKey && this.apiKey.length > 5;
  }

  /**
   * Get filtered speaker list by category and search
   */
  getSpeakers(genderFilter = 'all', searchQuery = '') {
    const q = (searchQuery || '').trim().toLowerCase();
    return this.speakers.filter(s => {
      if (genderFilter === 'male' && s.gender !== 'male') return false;
      if (genderFilter === 'female' && s.gender !== 'female') return false;
      if (q) {
        const full = `${s.id} ${s.name} ${s.gender} ${s.tag} ${s.desc}`.toLowerCase();
        return full.includes(q);
      }
      return true;
    });
  }

  /**
   * Get speaker display name
   */
  getSpeakerName(speakerId) {
    const s = this.speakers.find(sp => sp.id === (speakerId || '').toLowerCase());
    if (s) return `${s.name} (${s.gender === 'male' ? '👨 Male' : '👩 Female'})`;
    return speakerId ? (speakerId.charAt(0).toUpperCase() + speakerId.slice(1)) : 'Shubh';
  }

  /**
   * Automatically detect language code based on unicode character ranges
   * Falls back to en-IN for Latin or hi-IN for Devanagari
   */
  detectLanguage(text) {
    if (!text) return 'hi-IN';

    // Unicode block checks
    const hasTamil = /[\u0B80-\u0BFF]/.test(text);
    if (hasTamil) return 'ta-IN';

    const hasTelugu = /[\u0C00-\u0C7F]/.test(text);
    if (hasTelugu) return 'te-IN';

    const hasKannada = /[\u0C80-\u0CFF]/.test(text);
    if (hasKannada) return 'kn-IN';

    const hasMalayalam = /[\u0D00-\u0D7F]/.test(text);
    if (hasMalayalam) return 'ml-IN';

    const hasBengali = /[\u0980-\u09FF]/.test(text);
    if (hasBengali) return 'bn-IN';

    const hasGujarati = /[\u0A80-\u0AFF]/.test(text);
    if (hasGujarati) return 'gu-IN';

    const hasGurmukhi = /[\u0A00-\u0A7F]/.test(text);
    if (hasGurmukhi) return 'pa-IN';

    const hasOdia = /[\u0B00-\u0B7F]/.test(text);
    if (hasOdia) return 'od-IN';

    const hasDevanagari = /[\u0900-\u097F]/.test(text);
    if (hasDevanagari) return 'hi-IN';

    // Pure Latin text: English
    return 'en-IN';
  }

  /**
   * Generate speech using Sarvam AI REST API
   * Endpoint: POST https://api.sarvam.ai/text-to-speech
   * Header: api-subscription-key: <key>
   *
   * @param {string} text - Message text to synthesize
   * @param {string} speaker - Speaker ID (e.g. 'shubh', 'priya', 'aditya')
   * @param {object} options - Generation options (model, languageCode, pace, temperature, sampleRate)
   * @returns {Promise<{blob: Blob, url: string, duration: number, audioBuffer: AudioBuffer}>}
   */
  async generateSpeech(text, speaker = 'shubh', options = {}) {
    if (!this.hasApiKey()) {
      throw new Error("Missing Sarvam AI API Key. Please click Sarvam AI in the top bar to enter your key.");
    }

    const cleanText = (text || '').trim();
    if (!cleanText) {
      throw new Error("Cannot generate audio: text is empty.");
    }

    const model = options.model || this.defaultModel || 'bulbul:v3';
    const targetSpeaker = (speaker || this.defaultSpeaker || 'shubh').toLowerCase();
    
    // Determine language: manual override or auto-detect
    let languageCode = options.languageCode;
    if (!languageCode || languageCode === 'auto') {
      languageCode = this.detectLanguage(cleanText);
    }

    const pace = options.pace !== undefined ? parseFloat(options.pace) : 1.0;
    const temperature = options.temperature !== undefined ? parseFloat(options.temperature) : 0.6;
    const sampleRate = options.sampleRate ? parseInt(options.sampleRate, 10) : 22050;

    // Construct Sarvam AI Payload
    const payload = {
      text: cleanText,
      language_code: languageCode,
      speaker: targetSpeaker,
      model: model,
      pace: Math.max(0.5, Math.min(2.0, pace)),
      enable_preprocessing: true
    };

    // Bulbul v3 supports temperature & higher sample rates
    if (model === 'bulbul:v3') {
      payload.temperature = Math.max(0.01, Math.min(1.0, temperature));
      if ([8000, 16000, 22050, 24000, 32000, 44100, 48000].includes(sampleRate)) {
        payload.speech_sample_rate = sampleRate;
      }
    }

    const response = await fetch('https://api.sarvam.ai/text-to-speech', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-subscription-key': this.apiKey
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errText = await response.text();
      let message = `Sarvam AI API error (${response.status})`;
      try {
        const errJson = JSON.parse(errText);
        if (errJson.detail) {
          message += `: ${typeof errJson.detail === 'string' ? errJson.detail : JSON.stringify(errJson.detail)}`;
        } else if (errJson.message) {
          message += `: ${errJson.message}`;
        } else {
          message += `: ${errText.substring(0, 200)}`;
        }
      } catch (e) {
        message += `: ${errText.substring(0, 200)}`;
      }
      throw new Error(message);
    }

    const resJson = await response.json();
    if (!resJson.audios || !Array.isArray(resJson.audios) || resJson.audios.length === 0) {
      throw new Error("Sarvam AI returned an empty audio response.");
    }

    // Sarvam returns base64 WAV strings in audios array
    const base64Wav = resJson.audios[0];
    const binaryStr = atob(base64Wav);
    const len = binaryStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }

    const audioBlob = new Blob([bytes.buffer], { type: 'audio/wav' });
    const audioUrl = URL.createObjectURL(audioBlob);

    // Decode AudioBuffer for exact duration & WhatsApp waveform bars
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const audioBuffer = await audioCtx.decodeAudioData(bytes.buffer.slice(0));

    return {
      blob: audioBlob,
      url: audioUrl,
      duration: audioBuffer.duration,
      audioBuffer: audioBuffer,
      languageCode: languageCode,
      speaker: targetSpeaker
    };
  }

  /**
   * Browser Speech Synthesis fallback (no API key required)
   */
  async generateBrowserVoice(text, voiceIndex = 0, gender = 'female') {
    return new Promise(async (resolve, reject) => {
      try {
        if (!('speechSynthesis' in window)) {
          throw new Error("Web Speech API not supported in this browser.");
        }

        const voices = window.speechSynthesis.getVoices();
        const utterance = new SpeechSynthesisUtterance(text);

        if (voices.length > 0) {
          const indianVoice = voices.find(v =>
            v.lang === 'hi-IN' || v.lang === 'en-IN' ||
            v.lang.startsWith('hi') || v.lang.startsWith('ta') ||
            v.lang.startsWith('te') || v.lang.startsWith('bn')
          );
          if (indianVoice) {
            utterance.voice = indianVoice;
          } else if (voices[voiceIndex]) {
            utterance.voice = voices[voiceIndex];
          } else {
            utterance.voice = voices[0];
          }
        }

        const wordCount = text.trim().split(/\s+/).length;
        const estimatedSeconds = Math.max(1.8, wordCount / 2.6);

        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const sampleRate = audioCtx.sampleRate;
        const totalSamples = Math.ceil(estimatedSeconds * sampleRate);
        const audioBuffer = audioCtx.createBuffer(1, totalSamples, sampleRate);
        const channelData = audioBuffer.getChannelData(0);

        const baseFreq = gender === 'female' ? 220 : 130;
        for (let i = 0; i < totalSamples; i++) {
          const t = i / sampleRate;
          const env = Math.sin((t / estimatedSeconds) * Math.PI);
          const vocalTract = Math.sin(2 * Math.PI * baseFreq * t) * 0.4 +
                             Math.sin(2 * Math.PI * baseFreq * 2 * t) * 0.2 +
                             (Math.random() - 0.5) * 0.04;
          const syllableMod = Math.abs(Math.sin(t * 7));
          channelData[i] = vocalTract * env * syllableMod * 0.25;
        }

        const wavBlob = SarvamClient.bufferToWave(audioBuffer, totalSamples);
        const audioUrl = URL.createObjectURL(wavBlob);

        resolve({
          blob: wavBlob,
          url: audioUrl,
          duration: estimatedSeconds,
          audioBuffer: audioBuffer,
          speakNative: () => {
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(utterance);
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  /**
   * Convert AudioBuffer to WAV Blob
   */
  static bufferToWave(abuffer, totalSamples) {
    const numOfChan = abuffer.numberOfChannels;
    const length = totalSamples * numOfChan * 2 + 44;
    const out = new ArrayBuffer(length);
    const view = new DataView(out);
    let offset = 0;
    let pos = 0;

    function setUint16(data) {
      view.setUint16(offset, data, true);
      offset += 2;
    }
    function setUint32(data) {
      view.setUint32(offset, data, true);
      offset += 4;
    }

    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8);
    setUint32(0x45564157); // "WAVE"
    setUint32(0x20746d66); // "fmt "
    setUint32(16);
    setUint16(1);          // PCM
    setUint16(numOfChan);
    setUint32(abuffer.sampleRate);
    setUint32(abuffer.sampleRate * 2 * numOfChan);
    setUint16(numOfChan * 2);
    setUint16(16);
    setUint32(0x61746164); // "data"
    setUint32(length - pos - 4);

    const channels = [];
    for (let i = 0; i < abuffer.numberOfChannels; i++) {
      channels.push(abuffer.getChannelData(i));
    }

    while (pos < totalSamples) {
      for (let i = 0; i < numOfChan; i++) {
        let sample = Math.max(-1, Math.min(1, channels[i][pos]));
        sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
        view.setInt16(offset, sample, true);
        offset += 2;
      }
      pos++;
    }

    return new Blob([out], { type: "audio/wav" });
  }
}

window.SarvamClient = SarvamClient;
